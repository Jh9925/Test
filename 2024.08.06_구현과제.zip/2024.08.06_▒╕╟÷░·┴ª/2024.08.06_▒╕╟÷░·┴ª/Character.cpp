#include "Character.h"

Character::Character(const string& n, const int hp, const int atk, const int def)
	: Name(n), Hp(hp), Atk(atk), Def(def)
{
}

Character::~Character()
{
}
