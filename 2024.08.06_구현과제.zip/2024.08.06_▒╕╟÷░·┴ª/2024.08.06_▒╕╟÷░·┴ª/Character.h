#pragma once

#include<iostream>
using namespace std;


class Character
{
protected:
	string Name;
	int Hp;
	int Atk;
	int Def;

public:
	Character(const string& n, const int hp, const int atk, const int def);
	virtual~Character();

	virtual void Move();
	virtual void Attack();
	virtual void TakeDamage();
	
};

